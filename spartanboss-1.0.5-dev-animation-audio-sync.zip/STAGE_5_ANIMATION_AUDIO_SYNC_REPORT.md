# SpartanBoss 1.0.5-dev — Animation and Audio Synchronization

## Implemented

### Kratos
- Added a dedicated 0.9-second `animation.spartan.telegraph` pose for the existing 18-tick heavy-slam and rage-burst warning sequences.
- Added `animation.spartan.ultimate`, a 3.9-second animation aligned to the 78-tick Wrath of Sparta sequence.
- Added GeckoLib trigger registrations for `telegraph` and `ultimate`; the existing ultimate start now triggers the dedicated clip instead of reusing the rage loop.
- Added the existing `kratos.slam` sound event at the first Wrath of Sparta wave, so the first expanding wave has an impact cue. The final-wave rage cue remains unchanged.

### Gabriel
- Added `animation.gabriel.ultimate`, a 4.0-second dedicated Divine Annihilation animation with a rising pose, halo movement, and wing spread.
- Added the `ultimate` trigger to Gabriel's existing controller and switched the Phase III ultimate to that dedicated clip instead of reusing Judgment.
- Kept the existing first-strike thunder cue and second-strike divine cue at their respective server-side impact points.
- The animation duration matches the supplied ultimate voice line (~3.997 seconds); the gameplay sequence lasts 75 ticks (3.75 seconds), leaving a short 5-tick recovery tail.

### Synchronization approach
- Animation triggers and impact sounds are initiated from the boss entity's server-side sequence code.
- Existing sound event IDs, OGG voice assets, cooldowns, boss phases, attack damage, and attack timing were otherwise left unchanged.

## Validation performed
- Parsed all 15 Java source files using the JDK compiler parser; no Java syntax errors were reported.
- Parsed all 22 JSON resource files.
- Checked that every `thenPlay` animation referenced from Java has a matching clip in the corresponding animation JSON.
- Checked that every newly animated bone exists in the relevant GeckoLib entity model.
- Verified all 14 OGG voice assets and their sound event registrations remain present.
- Verified the Kratos first-wave and Gabriel two-strike sound cues are attached to the expected server-side sequence branches.
- Verified ZIP integrity after packaging.

## Not yet verified
- A full Fabric/GeckoLib Gradle build was not possible in this environment: Gradle is unavailable and the project does not include a Gradle wrapper.
- Animation appearance, transitions, voice audibility, and multiplayer playback still require an actual Minecraft 1.21.11 + Fabric + GeckoLib 5.4.6 client/server playtest.
- No compiled JAR is included.
