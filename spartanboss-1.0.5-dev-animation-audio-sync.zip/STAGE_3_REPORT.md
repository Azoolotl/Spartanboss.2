# SpartanBoss — Stage 3 implementation report

## Implemented

### Shared combat systems
- Added `BossTelegraph`, a shared server-side ground-ring warning with a configured location, radius, and duration. It reports completion once, on the final warning tick.
- Added `BossTargeting` for focused multiplayer target selection. A valid current player target is retained; the boss acquires the nearest valid player only when the current target is absent, invalid, or outside its configured follow range.
- Added `BossDodgeController` for a small lateral/retreat impulse when a boss successfully avoids an incoming player-originated hit.
- Current attack sequences are not canceled by a stun check. Stun still stops normal navigation and prevents the boss from starting a new attack, but an attack sequence already underway continues to its scheduled resolution.

### Kratos
- **Heavy ground slam:** now has an 18-tick red warning ring with a 10-block radius before the existing frost slam resolves.
- **Rage burst:** now has an 18-tick warning ring before its existing Phase/rage area attack resolves.
- **Wrath of Sparta (Phase III ultimate):** 30-tick warning ring, followed by three expanding fire waves. Each wave can hit grounded players for 12 damage; the ultimate sequence lasts 78 ticks and has a 900-tick cooldown.
- The Phase III boss-bar title now displays `KRATOS – WRATH OF SPARTA`.
- Moderate dodge: 15% avoidance chance against a player-originated hit, with an 80-tick cooldown. A successful close-range direct-melee dodge retains Kratos's existing 8-damage counter.

### Gabriel
- **Judgment:** retains its existing 35-tick target marker, now implemented through the shared telegraph manager; its existing impact remains unchanged.
- **Crossfire:** now marks the target area with an 18-tick, 6-block warning ring before the existing paired-projectile crossfire fires toward the marked position.
- **Divine Annihilation (Phase III ultimate):** marks the target area for 30 ticks with an 8-block radius, then resolves a 24-damage strike. A second 12-tick warning at an 11-block radius precedes a 12-damage aftershock. The sequence lasts 75 ticks and has a 900-tick cooldown.
- The Phase III boss-bar title now displays `Gabriel – DIVINE ANNIHILATION`.
- Moderate dodge: 15% avoidance chance against a player-originated hit, with an 80-tick cooldown.

### Save data
- Added persistent ultimate cooldowns for both bosses and a persistent dodge cooldown for Gabriel. Kratos reuses its existing `DefenseCooldown` field for its dodge cooldown.
- Existing Stage 2 phase values and attack/ability cooldown keys are retained.
- The mod version is now `1.0.3-dev`.

## Validation performed
- Parsed all 15 Java source files with the Java 21 compiler parser; no syntax errors were reported.
- Compiled the new targeting and dodge helper classes against API-shaped Minecraft test doubles to check their Java typing and method flow.
- Compiled and ran a focused `BossTelegraph` test with minimal test doubles. It verified warning duration, final-tick completion, one-time completion behavior, particle emission, and clearing.
- Rechecked that the Phase III ultimate paths are gated by `BossPhase.PHASE_THREE`, and that new cooldowns are read from and written to entity NBT.
- Verified the packaged source archive after creation.

## Limitations / not yet verified
- A full Fabric/GeckoLib Gradle build was not possible: Java 21 is present, but Gradle is not installed, there is no Gradle wrapper in the project, and the environment cannot resolve external hosts to download a Gradle distribution. No compiled JAR is included.
- The new telegraph and active attack-sequence progress are runtime state, like the pre-existing boss sequences; they are not serialized. Ultimate cooldowns are serialized, so unloading during an ultimate can end that in-progress sequence without immediately re-triggering it on reload.
- In-game balance, multiplayer synchronization, particle load, and the final animation/SFX timing still need to be playtested on a Fabric 1.21.11 client/server with GeckoLib 5.4.6.
- No new audio files or animation assets were added. The new sequences use existing GeckoLib triggers, current mod sound events, and Minecraft particle effects.
