# Spartan Boss Overhaul — Stage 1 Report

## Stage 1: Build foundation

### Changes applied
- Added the official GeckoLib Maven repository to `build.gradle`.
- Added GeckoLib as a Gradle `modImplementation` dependency so the source imports resolve during compilation.
- Pinned the Minecraft 1.21.11-compatible GeckoLib dependency to `5.4.6` in `gradle.properties`.
- Marked this source snapshot as `1.0.1-dev` to distinguish it from the supplied `1.0.0` JAR.

### Why this was necessary
The source imports GeckoLib APIs in the common and client source sets, and `fabric.mod.json` already declares GeckoLib as a runtime dependency. The original Gradle build did not declare GeckoLib's Maven repository or compile dependency. This patch aligns the Gradle setup with the existing source imports and runtime dependency declaration.

### Intentionally not changed yet
- No boss combat behavior, damage values, attack timings, health, or animations were changed.
- The additional `DamageUtil.getInflictedDamage(..., 16)` mitigation in both boss classes is flagged for a controlled damage-pipeline test before changing it. Removing it without a baseline could unintentionally alter the intended boss durability.
- No final JAR was produced in this stage.

### Validation status
- Source archive structure retained.
- Build configuration and properties updated.
- Full Gradle compilation was **not run** in this environment because a Gradle executable or Gradle wrapper is not included/available here.
- The project still needs a clean Gradle build on a machine with Java 21 and network access to the configured Maven repositories.

## Next stage
Stage 2 will establish shared phase/attack state and persistence, then add testable phase-transition logic for Kratos and Gabriel before introducing the new attack patterns.
