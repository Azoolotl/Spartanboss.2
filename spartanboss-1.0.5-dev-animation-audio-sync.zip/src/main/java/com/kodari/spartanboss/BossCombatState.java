package com.kodari.spartanboss;

/** Shared cooldown state for boss attack selection. Attack patterns remain boss-specific. */
public final class BossCombatState {
    private final int[] abilityCooldowns;
    private int attackCooldown;

    public BossCombatState(int abilityCount, int initialAttackCooldown) {
        if (abilityCount < 1) throw new IllegalArgumentException("A boss must define at least one ability slot");
        this.abilityCooldowns = new int[abilityCount];
        this.attackCooldown = Math.max(0, initialAttackCooldown);
    }

    public void tickCooldowns() {
        if (attackCooldown > 0) attackCooldown--;
        for (int i = 0; i < abilityCooldowns.length; i++) {
            if (abilityCooldowns[i] > 0) abilityCooldowns[i]--;
        }
    }

    public int getAttackCooldown() {
        return attackCooldown;
    }

    public void setAttackCooldown(int ticks) {
        attackCooldown = Math.max(0, ticks);
    }

    public int getAbilityCount() {
        return abilityCooldowns.length;
    }

    public int getAbilityCooldown(int index) {
        return abilityCooldowns[index];
    }

    public void setAbilityCooldown(int index, int ticks) {
        abilityCooldowns[index] = Math.max(0, ticks);
    }
}
