package com.kodari.spartanboss;

/** Shared, monotonic phase state used by all SpartanBoss encounters. */
public enum BossPhase {
    PHASE_ONE(1, 1.0f),
    PHASE_TWO(2, 0.70f),
    PHASE_THREE(3, 0.35f);

    private final int id;
    private final float entryHealthRatio;

    BossPhase(int id, float entryHealthRatio) {
        this.id = id;
        this.entryHealthRatio = entryHealthRatio;
    }

    public int getId() {
        return id;
    }

    public boolean isAtLeast(BossPhase other) {
        return ordinal() >= other.ordinal();
    }

    public static BossPhase fromId(int id) {
        return switch (id) {
            case 2 -> PHASE_TWO;
            case 3 -> PHASE_THREE;
            default -> PHASE_ONE;
        };
    }

    public static BossPhase fromHealth(float health, float maxHealth) {
        if (maxHealth <= 0.0f) return PHASE_ONE;
        float ratio = Math.max(0.0f, Math.min(1.0f, health / maxHealth));
        if (ratio <= PHASE_THREE.entryHealthRatio) return PHASE_THREE;
        if (ratio <= PHASE_TWO.entryHealthRatio) return PHASE_TWO;
        return PHASE_ONE;
    }
}
