package com.kodari.spartanboss;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.block.Blocks;
import net.minecraft.entity.DamageUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.storage.ReadView;
import net.minecraft.storage.WriteView;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

public class SpartanEntity extends HostileEntity implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossBar bar = new ServerBossBar(Text.literal("KRATOS – THE GHOST OF SPARTA"), BossBar.Color.RED, BossBar.Style.PROGRESS);
    private final BossCombatState combatState = new BossCombatState(14, 100);
    private final BossTelegraph telegraph = new BossTelegraph();
    private final Set<UUID> waveHits = new HashSet<>();
    private BossPhase bossPhase = BossPhase.PHASE_ONE;
    private int rageTicks;
    private int rageCooldown;
    private int defenseCooldown;
    private int ultimateCooldown;
    private int axeHiddenTicks;
    private int ambientVoiceCooldown;
    private int damageVoiceCooldown;
    private boolean summonVoicePlayed;
    private int sequence = -1;
    private int sequenceAge;
    private int sequenceDuration;
    private LivingEntity sequenceTarget;

    public SpartanEntity(EntityType<? extends SpartanEntity> type, World world) {
        super(type, world);
        setPersistent();
        setEquipmentDropChance(EquipmentSlot.MAINHAND, 0);
        setEquipmentDropChance(EquipmentSlot.OFFHAND, 0);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes().add(EntityAttributes.MAX_HEALTH, 1000)
            .add(EntityAttributes.ATTACK_DAMAGE, 12).add(EntityAttributes.ARMOR, 15)
            .add(EntityAttributes.MOVEMENT_SPEED, 0.29).add(EntityAttributes.FOLLOW_RANGE, 40)
            .add(EntityAttributes.KNOCKBACK_RESISTANCE, 0.9).add(EntityAttributes.EXPLOSION_KNOCKBACK_RESISTANCE, 0.9);
    }

    @Override protected void initGoals() {
        goalSelector.add(1, new MeleeAttackGoal(this, 1.1, false));
        targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    protected void mobTick(ServerWorld world) {
        super.mobTick(world);
        if (!summonVoicePlayed) {
            playSound(SpartanBoss.KRATOS_SUMMONED, 2.4f, 1.0f);
            summonVoicePlayed = true;
            ambientVoiceCooldown = 600 + getRandom().nextInt(601);
        }
        if (damageVoiceCooldown > 0) damageVoiceCooldown--;
        if (ambientVoiceCooldown > 0) ambientVoiceCooldown--;
        if (ambientVoiceCooldown == 0 && getTarget() == null) {
            playSound(switch (getRandom().nextInt(3)) {
                case 0 -> SpartanBoss.KRATOS_AMBIENT_1;
                case 1 -> SpartanBoss.KRATOS_AMBIENT_2;
                default -> SpartanBoss.KRATOS_AMBIENT_3;
            }, 1.6f, 1.0f);
            ambientVoiceCooldown = 600 + getRandom().nextInt(601);
        }
        updateBossPhase(world);
        if (age % 20 == 0 && getHealth() < getMaxHealth()) heal(0.5f);
        bar.setPercent(getHealth() / getMaxHealth());
        boolean stunned = WeaponAbilitySequences.isStunned(this);
        if (stunned) getNavigation().stop();
        if (age % 10 == 0) {
            breakCobwebs(world);
            updateEquipment();
        }
        if (axeHiddenTicks > 0) axeHiddenTicks--;
        if (defenseCooldown > 0) defenseCooldown--;
        if (rageCooldown > 0) rageCooldown--;
        combatState.tickCooldowns();
        if (ultimateCooldown > 0) ultimateCooldown--;
        if (age % 10 == 0) BossTargeting.retainOrAcquire(this, world, 40.0);

        if (rageTicks > 0) {
            rageTicks--;
            if (age % 5 == 0) particles(world, new DustParticleEffect(0xD50000, 1.8f), 25, 0.7);
            if (rageTicks == 0) setKnockbackResistance(0.9);
        } else if (getTarget() != null && getHealth() <= getMaxHealth() * 0.65f && rageCooldown == 0) {
            rageTicks = 240;
            rageCooldown = isPhaseTwoOrHigher() ? 900 : 1500;
            addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 240, 0, false, false));
            addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 240, 0, false, false));
            addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 240, 0, false, false));
            setKnockbackResistance(0.97);
            playSound(SpartanBoss.RAGE_SOUND, 2.5f, 0.7f);
            particles(world, new DustParticleEffect(0xFF1800, 2.0f), 100, 1.3);
            triggerAnim("movement", "rage");
            updateEquipment();
        }
        if (sequence >= 0) {
            tickSequence(world);
            return;
        }
        if (stunned) return;
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive()) return;
        if (bossPhase == BossPhase.PHASE_THREE && ultimateCooldown == 0) {
            beginWrathOfSparta(world, target);
            return;
        }
        if (combatState.getAttackCooldown() > 0) return;
        List<Integer> available = new ArrayList<>();
        int first = rageTicks > 0 ? 11 : 0;
        int last = rageTicks > 0 ? 13 : isPhaseTwoOrHigher() ? 10 : 5;
        for (int i = first; i <= last; i++) {
            if (combatState.getAbilityCooldown(i) == 0 && (i != 0 || axeHiddenTicks == 0)) available.add(i);
        }
        if (available.isEmpty()) {
            combatState.setAttackCooldown(30);
            return;
        }
        int choice = available.get(getRandom().nextInt(available.size()));
        combatState.setAbilityCooldown(choice, rageTicks > 0 ? 400 : isPhaseTwoOrHigher() ? 420 : 600);
        combatState.setAttackCooldown(rageTicks > 0 ? 45 : isPhaseTwoOrHigher() ? 90 : 120);
        triggerAnim("movement", rageTicks > 0 ? "rage" : "attack");
        useAbility(world, target, choice);
    }

    private void useAbility(ServerWorld world, LivingEntity target, int choice) {
        switch (choice) {
            case 0 -> {
                if (CombatProjectileEntity.launch(world, this, new ItemStack(SpartanBoss.FROST_AXE), CombatProjectileEntity.AXE,
                        target.getEyePos().subtract(getEyePos()), isPhaseTwoOrHigher() ? 16.5f : 15.0f)) {
                    axeHiddenTicks = 100;
                    updateEquipment();
                }
                playSound(SpartanBoss.FROST_SOUND, 2, 0.8f);
            }
            case 1 -> startSequence(1, 20, target);
            case 2 -> cone(world, target, 4.5, 20, true, false, 0.5);
            case 3 -> {
                startSequence(15, 18, target);
                telegraph.start(getX(), getY(), getZ(), 10.0, 18);
                triggerAnim("movement", "telegraph");
                playSound(SpartanBoss.SLAM_SOUND, 1.8f, 0.75f);
            }
            case 4 -> {
                launchToward(target, 1.0, 0.8);
                startSequence(4, 60, target);
            }
            case 5 -> {
                startSequence(5, 24, target);
                playSound(SpartanBoss.RAGE_SOUND, 1.5f, 1.2f);
            }
            case 6 -> {
                startSequence(6, 16, target);
                playSound(SpartanBoss.CHAIN_SOUND, 2, 0.9f);
            }
            case 7 -> startSequence(7, 60, target);
            case 8 -> startSequence(8, 36, target);
            case 9 -> startSequence(9, 60, target);
            case 10 -> {
                launchToward(target, 1.4, 0.2);
                startSequence(10, 50, target);
            }
            case 11 -> startSequence(11, 48, target);
            case 12 -> {
                setVelocity(0, 1.0, 0);
                velocityDirty = true;
                startSequence(12, 60, target);
            }
            case 13 -> {
                startSequence(16, 18, target);
                telegraph.start(getX(), getY(), getZ(), 10.0, 18);
                triggerAnim("movement", "telegraph");
                playSound(SpartanBoss.RAGE_SOUND, 2.0f, 0.7f);
            }
            default -> throw new IllegalArgumentException("Unknown combat ability");
        }
    }

    private void startSequence(int ability, int duration, LivingEntity target) {
        sequence = ability;
        sequenceAge = 0;
        sequenceDuration = duration;
        sequenceTarget = target;
        waveHits.clear();
    }

    private void beginWrathOfSparta(ServerWorld world, LivingEntity target) {
        startSequence(14, 78, target);
        telegraph.start(getX(), getY(), getZ(), 14.0, 30);
        ultimateCooldown = 900;
        combatState.setAttackCooldown(180);
        triggerAnim("movement", "ultimate");
        playSound(SpartanBoss.KRATOS_ULTIMATE, 3.0f, 1.0f);
        particles(world, new DustParticleEffect(0xFF1800, 2.2f), 120, 2.0);
    }

    private void tickSequence(ServerWorld world) {
        sequenceAge++;
        LivingEntity target = sequenceTarget;
        if (sequence == 15) {
            if (telegraph.tick(world, new DustParticleEffect(0xE52B1B, 1.45f))) {
                area(world, 10, 18, true, false, 1.2);
                ArenaEffects.explosion(world, this, 3.0f);
                ArenaEffects.frostSpikes(world, this, 10);
                playSound(SpartanBoss.SLAM_SOUND, 2.0f, 0.7f);
            }
        } else if (sequence == 16) {
            if (telegraph.tick(world, new DustParticleEffect(0xFF3A12, 1.65f))) {
                area(world, 10, 20, false, false, 1.2);
                particles(world, new DustParticleEffect(0xFF1200, 2.0f), 120, 3);
                ArenaEffects.explosion(world, this, 3.5f);
                playSound(SpartanBoss.RAGE_SOUND, 2.5f, 0.65f);
            }
        } else if (sequence == 14) {
            if (telegraph.isActive()) {
                telegraph.tick(world, new DustParticleEffect(0xFF3018, 1.8f));
            } else {
                int elapsed = sequenceAge - 30;
                if (elapsed >= 1 && elapsed <= 45) {
                    int wave = (elapsed - 1) / 15;
                    int waveTick = (elapsed - 1) % 15 + 1;
                    if (waveTick == 1) {
                        waveHits.clear();
                        if (wave == 0) playSound(SpartanBoss.SLAM_SOUND, 2.8f, 0.85f);
                    }
                    double radius = waveTick * 0.86;
                    ArenaEffects.ring(world, this, ParticleTypes.FLAME, radius, 64);
                    damageWave(world, radius, 12.0f, false, true);
                    if (waveTick == 15 && wave == 2) {
                        ArenaEffects.firePatches(world, this, 18);
                        ArenaEffects.explosion(world, this, 3.5f);
                        playSound(SpartanBoss.RAGE_SOUND, 3.0f, 0.65f);
                    }
                }
            }
        } else if (sequence == 1) {
            double radius = sequenceAge * 0.6;
            ArenaEffects.ring(world, this, ParticleTypes.SNOWFLAKE, radius, 48);
            damageWave(world, radius, 15, true, false);
            if (sequenceAge == 20) ArenaEffects.frostSpikes(world, this, 12);
        } else if (sequence == 4 || sequence == 12) {
            if (sequenceAge > 8 && isOnGround()) {
                boolean rageSlam = sequence == 12;
                area(world, rageSlam ? 15 : 4, rageSlam ? 25 : 15, false, false, rageSlam ? 1.5 : 1.0);
                ArenaEffects.explosion(world, this, rageSlam ? 4.0f : 2.5f);
                particles(world, rageSlam ? new DustParticleEffect(0xCE1300, 2.0f) : ParticleTypes.CRIT, 80, 2);
                sequenceAge = sequenceDuration;
            }
        } else if (sequence == 5) {
            particles(world, new DustParticleEffect(0xFF2020, 1.3f), 8, 0.6);
            if (sequenceAge == 24 && target != null && target.isAlive()) {
                cone(world, target, 5, 25, false, false, 1.2);
                ArenaEffects.explosion(world, this, 2.0f);
            }
        } else if (sequence == 6 && target != null && target.isAlive()) {
            chain(world, target, sequenceAge <= 8 ? sequenceAge / 8.0 : (16 - sequenceAge) / 8.0);
            if (sequenceAge == 8 && distanceTo(target) <= 15) {
                target.damage(world, getDamageSources().mobAttack(this), isPhaseTwoOrHigher() ? 16.5f : 15);
                target.setOnFireFor(3);
                push(target, -1.0);
            }
        } else if (sequence == 7) {
            ArenaEffects.ring(world, this, ParticleTypes.FLAME, 12, 64);
            if (sequenceAge % 10 == 0) area(world, 12, 3, false, true, 0.1);
        } else if (sequence == 8 && target != null && target.isAlive()) {
            chain(world, target, Math.min(1, (sequenceAge % 12) / 6.0));
            if (sequenceAge % 12 == 0) {
                cone(world, target, 7, 8, false, true, 0.6);
                if (sequenceAge == 36) world.createExplosion(this, target.getX(), target.getY(), target.getZ(), 1.8f, World.ExplosionSourceType.MOB);
            }
        } else if (sequence == 9) {
            int waveAge = (sequenceAge - 1) % 20 + 1;
            if (waveAge == 1) waveHits.clear();
            double radius = waveAge * 0.75;
            ArenaEffects.ring(world, this, ParticleTypes.FLAME, radius, 64);
            damageWave(world, radius, 20, false, true);
            if (waveAge == 20) ArenaEffects.firePatches(world, this, 15);
            if (sequenceAge == 60) ArenaEffects.explosion(world, this, 2.5f);
        } else if (sequence == 10) {
            if (target != null && target.isAlive() && sequenceAge % 10 == 1) launchToward(target, 1.05, 0.12);
            if (sequenceAge % 10 == 0) {
                area(world, 4, 5, false, true, sequenceAge == 50 ? 1.0 : 0.15);
                if (sequenceAge == 50) ArenaEffects.explosion(world, this, 2.5f);
            }
        } else if (sequence == 11 && sequenceAge % 12 == 0) {
            area(world, 3.5, 6, false, false, sequenceAge == 48 ? 1.2 : 0.1);
            triggerAnim("movement", "rage");
        }
        if (sequenceAge >= sequenceDuration) {
            sequence = -1;
            sequenceTarget = null;
            waveHits.clear();
        }
    }

    private void damageWave(ServerWorld world, double radius, float damage, boolean frost, boolean fire) {
        for (PlayerEntity player : world.getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(radius + 1),
                p -> p.isAlive() && !p.isCreative() && !p.isSpectator() && !waveHits.contains(p.getUuid()))) {
            double dx = player.getX() - getX(), dz = player.getZ() - getZ();
            double distance = Math.sqrt(dx * dx + dz * dz);
            if (Math.abs(player.getY() - getY()) > 2.0 || (fire && !player.isOnGround()) || Math.abs(distance - radius) > 1.2) continue;
            waveHits.add(player.getUuid());
            player.damage(world, getDamageSources().mobAttack(this), damage * (isPhaseTwoOrHigher() ? 1.1f : 1));
            if (frost) player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 2));
            if (fire) player.setOnFireFor(4);
        }
    }

    private void chain(ServerWorld world, LivingEntity target, double extension) {
        Vec3d start = getEyePos();
        Vec3d direction = target.getEyePos().subtract(start);
        double length = Math.min(15, direction.length()) * Math.max(0, extension);
        direction = direction.normalize();
        for (int i = 0; i <= 24; i++) {
            Vec3d point = start.add(direction.multiply(length * i / 24.0));
            world.spawnParticles(i % 3 == 0 ? ParticleTypes.FLAME : ParticleTypes.CRIT, point.x, point.y, point.z, 1, 0.03, 0.03, 0.03, 0);
        }
    }

    private void cone(ServerWorld world, LivingEntity target, double radius, float damage, boolean frost, boolean fire, double knockback) {
        Vec3d facing = new Vec3d(target.getX() - getX(), 0, target.getZ() - getZ()).normalize();
        for (PlayerEntity player : world.getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(radius), p -> p.isAlive() && !p.isCreative() && !p.isSpectator())) {
            Vec3d offset = new Vec3d(player.getX() - getX(), 0, player.getZ() - getZ());
            if (offset.length() > radius || Math.abs(player.getY() - getY()) > 3 || offset.normalize().dotProduct(facing) < -0.1) continue;
            player.damage(world, getDamageSources().mobAttack(this), damage * (isPhaseTwoOrHigher() ? 1.1f : 1));
            if (frost) player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1));
            if (fire) player.setOnFireFor(3);
            push(player, knockback);
        }
        particles(world, frost ? ParticleTypes.SNOWFLAKE : fire ? ParticleTypes.FLAME : ParticleTypes.SWEEP_ATTACK, 40, 1.5);
        playSound(frost ? SpartanBoss.FROST_SOUND : fire ? SpartanBoss.CHAIN_SOUND : SpartanBoss.SLAM_SOUND, 1.5f, 1);
    }

    private void area(ServerWorld world, double radius, float damage, boolean frost, boolean fire, double knockback) {
        ParticleEffect effect = frost ? ParticleTypes.SNOWFLAKE : fire ? ParticleTypes.FLAME : ParticleTypes.CRIT;
        ArenaEffects.ring(world, this, effect, radius, 48);
        for (PlayerEntity player : world.getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(radius), p -> p.isAlive() && !p.isCreative() && !p.isSpectator())) {
            if (squaredDistanceTo(player) > radius * radius) continue;
            player.damage(world, getDamageSources().mobAttack(this), damage * (isPhaseTwoOrHigher() ? 1.1f : 1));
            if (frost) player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 2));
            if (fire) player.setOnFireFor(3);
            if (knockback != 0) push(player, knockback);
        }
        playSound(frost ? SpartanBoss.FROST_SOUND : fire ? SpartanBoss.CHAIN_SOUND : SpartanBoss.SLAM_SOUND, 1.5f, 0.8f);
    }

    private void launchToward(LivingEntity target, double speed, double up) {
        Vec3d direction = new Vec3d(target.getX() - getX(), 0, target.getZ() - getZ()).normalize();
        setVelocity(direction.x * speed, up, direction.z * speed);
        velocityDirty = true;
    }

    private void push(LivingEntity target, double strength) {
        Vec3d direction = new Vec3d(target.getX() - getX(), 0, target.getZ() - getZ()).normalize();
        target.setVelocity(direction.x * strength, 0.4, direction.z * strength);
        target.velocityDirty = true;
    }

    private void particles(ServerWorld world, ParticleEffect effect, int count, double spread) {
        world.spawnParticles(effect, getX(), getY() + 1, getZ(), count, spread, spread, spread, 0.03);
    }

    private void breakCobwebs(ServerWorld world) {
        for (BlockPos pos : BlockPos.iterateOutwards(getBlockPos(), 1, 2, 1)) {
            if (world.getBlockState(pos).isOf(Blocks.COBWEB) && getBoundingBox().intersects(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1, pos.getY() + 1, pos.getZ() + 1)) world.breakBlock(pos, true, this, 512);
        }
    }

    private boolean isPhaseTwoOrHigher() {
        return bossPhase.isAtLeast(BossPhase.PHASE_TWO);
    }

    private void updateBossPhase(ServerWorld world) {
        BossPhase next = BossPhaseManager.advance(bossPhase, getHealth(), getMaxHealth());
        if (next == bossPhase) return;
        bossPhase = next;
        refreshPhasePresentation();
        if (bossPhase == BossPhase.PHASE_TWO) {
            particles(world, ParticleTypes.FLAME, 100, 2);
            playSound(SpartanBoss.RAGE_SOUND, 2, 0.8f);
        } else if (bossPhase == BossPhase.PHASE_THREE) {
            particles(world, new DustParticleEffect(0xFF2400, 2.2f), 140, 2.5);
            playSound(SpartanBoss.RAGE_SOUND, 2.5f, 0.65f);
        }
        updateEquipment();
    }

    private void refreshPhasePresentation() {
        if (bossPhase == BossPhase.PHASE_THREE) {
            bar.setName(Text.literal("KRATOS – WRATH OF SPARTA"));
        } else if (bossPhase == BossPhase.PHASE_TWO) {
            bar.setName(Text.literal("KRATOS – THE GOD OF WAR"));
        } else {
            bar.setName(Text.literal("KRATOS – THE GHOST OF SPARTA"));
        }
        updateEquipment();
    }

    private void updateEquipment() {
        Item main = rageTicks > 0 ? null : isPhaseTwoOrHigher() ? SpartanBoss.CHAOS_BLADES : axeHiddenTicks > 0 ? null : SpartanBoss.FROST_AXE;
        Item off = rageTicks == 0 && isPhaseTwoOrHigher() && axeHiddenTicks == 0 ? SpartanBoss.FROST_AXE : null;
        setHeldItem(EquipmentSlot.MAINHAND, main);
        setHeldItem(EquipmentSlot.OFFHAND, off);
    }

    private void setHeldItem(EquipmentSlot slot, Item item) {
        ItemStack current = getEquippedStack(slot);
        if (item == null ? !current.isEmpty() : !current.isOf(item)) equipStack(slot, item == null ? ItemStack.EMPTY : new ItemStack(item));
    }

    private void setKnockbackResistance(double value) {
        EntityAttributeInstance attribute = getAttributeInstance(EntityAttributes.KNOCKBACK_RESISTANCE);
        if (attribute != null) attribute.setBaseValue(value);
        EntityAttributeInstance explosionAttribute = getAttributeInstance(EntityAttributes.EXPLOSION_KNOCKBACK_RESISTANCE);
        if (explosionAttribute != null) explosionAttribute.setBaseValue(value);
    }

    public void onAxeReturned() { axeHiddenTicks = 0; updateEquipment(); }
    public boolean isRaging() { return hasStatusEffect(StatusEffects.STRENGTH); }

    @Override protected float modifyAppliedDamage(DamageSource source, float amount) {
        float reduced = super.modifyAppliedDamage(source, amount);
        return source.isIn(DamageTypeTags.BYPASSES_EFFECTS) || source.isIn(DamageTypeTags.BYPASSES_ENCHANTMENTS)
            ? reduced : DamageUtil.getInflictedDamage(reduced, 16);
    }

    @Override public boolean handleFallDamage(double distance, float multiplier, DamageSource source) { return false; }
    @Override public boolean tryAttack(ServerWorld world, Entity target) {
        triggerAnim("movement", rageTicks > 0 ? "rage" : "attack");
        return super.tryAttack(world, target);
    }

    @Override public boolean damage(ServerWorld world, DamageSource source, float amount) {
        Entity attacker = source.getAttacker();
        if (defenseCooldown == 0 && attacker instanceof PlayerEntity player
                && !player.isCreative() && !player.isSpectator() && getRandom().nextInt(100) < 15) {
            defenseCooldown = 80;
            Vec3d dodgeVelocity = BossDodgeController.calculateVelocity(this, attacker, 0.82);
            setVelocity(dodgeVelocity.x, dodgeVelocity.y, dodgeVelocity.z);
            velocityDirty = true;
            playSound(SpartanBoss.CHAIN_SOUND, 1.0f, 1.5f);
            if (source.getSource() == attacker && distanceTo(player) < 4.0) {
                player.damage(world, getDamageSources().mobAttack(this), 8.0f);
                push(player, 0.8);
            }
            return false;
        }
        boolean damaged = super.damage(world, source, amount);
        if (damaged && damageVoiceCooldown == 0 && getRandom().nextFloat() < 0.35f) {
            playSound(SpartanBoss.KRATOS_DAMAGE, 1.5f, 1.0f);
            damageVoiceCooldown = 55;
        }
        return damaged;
    }

    @Override public void onDeath(DamageSource source) {
        if (!getEntityWorld().isClient()) {
            playSound(SpartanBoss.KRATOS_DEFEAT, 2.2f, 1.0f);
            dropItem(new ItemStack(SpartanBoss.FROST_AXE), true, false);
            dropItem(new ItemStack(SpartanBoss.CHAOS_BLADES), true, false);
        }
        super.onDeath(source);
    }

    @Override public void onStartedTrackingBy(ServerPlayerEntity player) { super.onStartedTrackingBy(player); bar.addPlayer(player); }
    @Override public void onStoppedTrackingBy(ServerPlayerEntity player) { super.onStoppedTrackingBy(player); bar.removePlayer(player); }
    @Override protected void readCustomData(ReadView view) {
        super.readCustomData(view);
        bossPhase = BossPhaseManager.read(view, getHealth(), getMaxHealth());
        rageCooldown = view.getInt("RageCooldown", 0);
        rageTicks = view.getInt("RageTicks", 0);
        combatState.setAttackCooldown(view.getInt("AttackCooldown", 100));
        defenseCooldown = view.getInt("DefenseCooldown", 0);
        ultimateCooldown = view.getInt("UltimateCooldown", 0);
        ambientVoiceCooldown = view.getInt("AmbientVoiceCooldown", 0);
        damageVoiceCooldown = view.getInt("DamageVoiceCooldown", 0);
        summonVoicePlayed = view.getBoolean("SummonVoicePlayed", false);
        telegraph.clear();
        for (int i = 0; i < combatState.getAbilityCount(); i++) combatState.setAbilityCooldown(i, view.getInt("AbilityCooldown" + i, 0));
        refreshPhasePresentation();
        setKnockbackResistance(rageTicks > 0 ? 0.97 : 0.9);
    }
    @Override protected void writeCustomData(WriteView view) {
        super.writeCustomData(view);
        BossPhaseManager.write(view, bossPhase);
        view.putInt("RageCooldown", rageCooldown);
        view.putInt("RageTicks", rageTicks);
        view.putInt("AttackCooldown", combatState.getAttackCooldown());
        view.putInt("DefenseCooldown", defenseCooldown);
        view.putInt("UltimateCooldown", ultimateCooldown);
        view.putInt("AmbientVoiceCooldown", ambientVoiceCooldown);
        view.putInt("DamageVoiceCooldown", damageVoiceCooldown);
        view.putBoolean("SummonVoicePlayed", summonVoicePlayed);
        for (int i = 0; i < combatState.getAbilityCount(); i++) view.putInt("AbilityCooldown" + i, combatState.getAbilityCooldown(i));
    }
    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>("movement", 5, state -> state.setAndContinue(RawAnimation.begin().thenLoop(state.isMoving() ? "animation.spartan.walk" : "animation.spartan.idle")))
            .triggerableAnim("attack", RawAnimation.begin().thenPlay("animation.spartan.attack"))
            .triggerableAnim("rage", RawAnimation.begin().thenPlay("animation.spartan.rage"))
            .triggerableAnim("telegraph", RawAnimation.begin().thenPlay("animation.spartan.telegraph"))
            .triggerableAnim("ultimate", RawAnimation.begin().thenPlay("animation.spartan.ultimate")));
    }
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}