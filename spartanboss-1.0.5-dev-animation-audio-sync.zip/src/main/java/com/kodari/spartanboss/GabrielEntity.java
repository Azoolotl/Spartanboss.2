package com.kodari.spartanboss;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Blocks;
import net.minecraft.entity.DamageUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.storage.ReadView;
import net.minecraft.storage.WriteView;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

public class GabrielEntity extends HostileEntity implements GeoEntity {
    static final double CRASH_RADIUS = 7;
    static final float CRASH_DAMAGE = 22;
    static final float CRASH_EXPLOSION_POWER = 3.8f;
    private static final TrackedData<Boolean> FLYING = DataTracker.registerData(GabrielEntity.class, TrackedDataHandlerRegistry.BOOLEAN);
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossBar bar = new ServerBossBar(Text.literal("Gabriel, The Judge of Heaven"), BossBar.Color.YELLOW, BossBar.Style.PROGRESS);
    private final BossCombatState combatState = new BossCombatState(6, 100);
    private final BossTelegraph telegraph = new BossTelegraph();
    private BossPhase bossPhase = BossPhase.PHASE_ONE;
    private int flightCooldown = 200;
    private int flightTicks;
    private int ultimateCooldown;
    private int dodgeCooldown;
    private boolean crashing;
    private int crashTicks;
    private int sequence;
    private int sequenceAge;
    private int sequenceDuration;
    private LivingEntity sequenceTarget;
    private double markedX;
    private double markedY;
    private double markedZ;
    private int ambientVoiceCooldown;
    private int damageVoiceCooldown;
    private boolean summonVoicePlayed;

    public GabrielEntity(EntityType<? extends GabrielEntity> type, World world) {
        super(type, world);
        setPersistent();
        setEquipmentDropChance(EquipmentSlot.MAINHAND, 0);
        setEquipmentDropChance(EquipmentSlot.OFFHAND, 0);
    }

    @Override protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(FLYING, false);
    }

    public boolean isFlying() { return getDataTracker().get(FLYING); }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes().add(EntityAttributes.MAX_HEALTH, 1000)
            .add(EntityAttributes.ATTACK_DAMAGE, 13).add(EntityAttributes.ARMOR, 15)
            .add(EntityAttributes.MOVEMENT_SPEED, 0.38).add(EntityAttributes.FOLLOW_RANGE, 48)
            .add(EntityAttributes.KNOCKBACK_RESISTANCE, 0.9).add(EntityAttributes.EXPLOSION_KNOCKBACK_RESISTANCE, 0.9);
    }

    @Override protected void initGoals() {
        goalSelector.add(1, new MeleeAttackGoal(this, 1.3, false) {
            @Override public boolean canStart() { return !isFlying() && !crashing && super.canStart(); }
            @Override public boolean shouldContinue() { return !isFlying() && !crashing && super.shouldContinue(); }
        });
        targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override protected void mobTick(ServerWorld world) {
        super.mobTick(world);
        if (!summonVoicePlayed) {
            playSound(SpartanBoss.GABRIEL_SUMMONED, 2.4f, 1.0f);
            summonVoicePlayed = true;
            ambientVoiceCooldown = 600 + getRandom().nextInt(601);
        }
        if (damageVoiceCooldown > 0) damageVoiceCooldown--;
        if (ambientVoiceCooldown > 0) ambientVoiceCooldown--;
        if (ambientVoiceCooldown == 0 && getTarget() == null) {
            playSound(switch (getRandom().nextInt(3)) {
                case 0 -> SpartanBoss.GABRIEL_AMBIENT_1;
                case 1 -> SpartanBoss.GABRIEL_AMBIENT_2;
                default -> SpartanBoss.GABRIEL_AMBIENT_3;
            }, 1.6f, 1.0f);
            ambientVoiceCooldown = 600 + getRandom().nextInt(601);
        }
        updateBossPhase(world);
        if (age % 20 == 0 && getHealth() < getMaxHealth()) heal(0.5f);
        bar.setPercent(getHealth() / getMaxHealth());
        boolean stunned = WeaponAbilitySequences.isStunned(this);
        if (stunned) getNavigation().stop();
        if (age % 10 == 0) {
            breakCobwebs(world);
            if (!getEquippedStack(EquipmentSlot.MAINHAND).isOf(SpartanBoss.BLADES)) equipStack(EquipmentSlot.MAINHAND, new ItemStack(SpartanBoss.BLADES));
            if (!getEquippedStack(EquipmentSlot.OFFHAND).isOf(SpartanBoss.BLADES)) equipStack(EquipmentSlot.OFFHAND, new ItemStack(SpartanBoss.BLADES));
        }
        if (age % 5 == 0) world.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 1, getZ(), isPhaseTwoOrHigher() ? 8 : 3, 0.6, 0.8, 0.6, 0.02);
        combatState.tickCooldowns();
        if (flightCooldown > 0) flightCooldown--;
        if (ultimateCooldown > 0) ultimateCooldown--;
        if (dodgeCooldown > 0) dodgeCooldown--;
        if (age % 10 == 0) BossTargeting.retainOrAcquire(this, world, 48.0);

        LivingEntity target = getTarget();
        if (flightTicks > 0) {
            tickFlight(world, target);
            return;
        }
        if (crashing) {
            tickCrash(world);
            return;
        }
        if (hasNoGravity()) setNoGravity(false);
        if (sequence != 0) {
            tickSequence(world);
            return;
        }
        if (stunned) return;
        if (target == null || !target.isAlive()) return;
        if (bossPhase == BossPhase.PHASE_THREE && ultimateCooldown == 0) {
            beginDivineAnnihilation(world, target);
            return;
        }
        if (flightCooldown == 0 && isOnGround()) {
            beginFlight();
            return;
        }
        if (combatState.getAttackCooldown() > 0) return;
        List<Integer> available = new ArrayList<>();
        for (int i = 0; i < combatState.getAbilityCount(); i++) if (combatState.getAbilityCooldown(i) == 0) available.add(i);
        if (available.isEmpty()) {
            combatState.setAttackCooldown(30);
            return;
        }
        int choice = available.get(getRandom().nextInt(available.size()));
        combatState.setAbilityCooldown(choice, isPhaseTwoOrHigher() ? 320 : 440);
        combatState.setAttackCooldown(isPhaseTwoOrHigher() ? 70 : 110);
        useAbility(world, target, choice);
    }

    private void beginFlight() {
        flightTicks = 100;
        getDataTracker().set(FLYING, true);
        setNoGravity(true);
        getNavigation().stop();
        setVelocity(0, 0.65, 0);
        velocityDirty = true;
        fallDistance = 0;
        playSound(SpartanBoss.DIVINE_SOUND, 2, 1.3f);
    }

    private void tickFlight(ServerWorld world, LivingEntity target) {
        getNavigation().stop();
        fallDistance = 0;
        int elapsed = 101 - flightTicks;
        flightTicks--;
        if (target == null || !target.isAlive()) flightTicks = 0;
        if (flightTicks == 0) {
            getDataTracker().set(FLYING, false);
            setNoGravity(false);
            crashing = true;
            crashTicks = 0;
            setVelocity(getVelocity().x * 0.35, -1.35, getVelocity().z * 0.35);
            velocityDirty = true;
            triggerAnim("movement", "dive");
            return;
        }
        double angle = elapsed * 0.13;
        boolean swooping = (elapsed >= 28 && elapsed <= 42) || (elapsed >= 65 && elapsed <= 79);
        double radius = swooping ? 1.2 : 4.0;
        Vec3d destination = target.getEntityPos().add(Math.cos(angle) * radius, swooping ? 2.1 : 5.0, Math.sin(angle) * radius);
        Vec3d offset = destination.subtract(getEntityPos());
        Vec3d velocity = offset.normalize().multiply(Math.min(swooping ? 0.85 : 0.55, offset.length() * 0.15));
        setVelocity(velocity);
        velocityDirty = true;
        world.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 1, getZ(), 5, 0.5, 0.5, 0.5, 0.04);
        if (elapsed == 28 || elapsed == 65) triggerAnim("movement", "dive");
        if ((elapsed == 40 || elapsed == 77) && distanceTo(target) < 4) strike(world, getX(), getY(), getZ(), 4, 15, 0.8);
        if (elapsed == 18 || elapsed == 57) shoot(world, target, CombatProjectileEntity.SPEAR, isPhaseTwoOrHigher() ? 25 : 22);
    }

    private void tickCrash(ServerWorld world) {
        getNavigation().stop();
        setNoGravity(false);
        fallDistance = 0;
        crashTicks++;
        if (crashTicks > 2 && isOnGround()) {
            crashing = false;
            flightCooldown = isPhaseTwoOrHigher() ? 480 : 640;
            combatState.setAttackCooldown(Math.max(combatState.getAttackCooldown(), 30));
            strike(world, getX(), getY(), getZ(), CRASH_RADIUS, CRASH_DAMAGE, 1.4);
            ArenaEffects.explosion(world, this, isPhaseTwoOrHigher() ? 4.2f : CRASH_EXPLOSION_POWER);
            world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY() + 0.5, getZ(), 1, 0, 0, 0, 0);
            world.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 1, getZ(), 100, 2.5, 1, 2.5, 0.15);
            playSound(SpartanBoss.CRASH_SOUND, 2.5f, 0.8f);
        }
    }

    private void beginDivineAnnihilation(ServerWorld world, LivingEntity target) {
        markedX = target.getX();
        markedY = target.getY();
        markedZ = target.getZ();
        startSequence(5, 75, target);
        telegraph.start(markedX, markedY, markedZ, 8.0, 30);
        ultimateCooldown = 900;
        combatState.setAttackCooldown(180);
        triggerAnim("movement", "ultimate");
        playSound(SpartanBoss.GABRIEL_ULTIMATE, 3.0f, 1.0f);
        world.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 1.5, getZ(), 100, 1.0, 1.0, 1.0, 0.12);
    }

    private void useAbility(ServerWorld world, LivingEntity target, int choice) {
        switch (choice) {
            case 0 -> {
                triggerAnim("movement", "spear");
                shoot(world, target, CombatProjectileEntity.SPEAR, isPhaseTwoOrHigher() ? 26 : 22);
            }
            case 1 -> {
                markedX = target.getX();
                markedY = target.getY();
                markedZ = target.getZ();
                startSequence(1, 35, target);
                telegraph.start(markedX, markedY, markedZ, 4.0, 35);
                triggerAnim("movement", "judgment");
                playSound(SpartanBoss.DIVINE_SOUND, 1.8f, 0.8f);
            }
            case 2 -> {
                startSequence(2, 36, target);
                triggerAnim("movement", "barrage");
            }
            case 3 -> {
                Vec3d facing = target.getRotationVec(1);
                Vec3d behind = target.getEntityPos().subtract(new Vec3d(facing.x, 0, facing.z).normalize().multiply(2.2));
                Box destination = getBoundingBox().offset(behind.subtract(getEntityPos()));
                if (world.isSpaceEmpty(this, destination) && !world.getBlockState(BlockPos.ofFloored(behind.x, behind.y - 0.1, behind.z)).isAir()) {
                    requestTeleport(behind.x, behind.y, behind.z);
                }
                startSequence(3, 36, target);
                triggerAnim("movement", "execution");
                playSound(SpartanBoss.DIVINE_SOUND, 1.5f, 1.6f);
            }
            case 4 -> {
                markedX = target.getX();
                markedY = target.getY();
                markedZ = target.getZ();
                startSequence(6, 18, target);
                telegraph.start(markedX, markedY, markedZ, 6.0, 18);
                triggerAnim("movement", "crossfire");
                playSound(SpartanBoss.DIVINE_SOUND, 1.5f, 1.1f);
            }
            case 5 -> {
                Vec3d direction = target.getEntityPos().subtract(getEntityPos()).normalize();
                setVelocity(direction.x * 1.3, 0.25, direction.z * 1.3);
                velocityDirty = true;
                startSequence(4, 30, target);
                triggerAnim("movement", "attack");
            }
            default -> throw new IllegalArgumentException("Unknown combat ability");
        }
    }

    private void startSequence(int ability, int duration, LivingEntity target) {
        sequence = ability;
        sequenceAge = 0;
        sequenceDuration = duration;
        sequenceTarget = target;
    }

    private void tickSequence(ServerWorld world) {
        sequenceAge++;
        LivingEntity target = sequenceTarget;
        if (sequence == 1) {
            if (telegraph.tick(world, new DustParticleEffect(0xFFD44A, 1.35f))) {
                for (int y = 0; y < 16; y++) world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, markedX, markedY + y, markedZ, 4, 0.3, 0.3, 0.3, 0.05);
                strike(world, markedX, markedY, markedZ, 4, 24, 1.0);
                world.createExplosion(this, markedX, markedY, markedZ, 3.0f, World.ExplosionSourceType.MOB);
                playSound(SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 2, 1.2f);
            }
        } else if (sequence == 5) {
            if (telegraph.isActive()) {
                if (telegraph.tick(world, new DustParticleEffect(0xFFF0A8, 1.8f))) {
                    if (sequenceAge < 40) {
                        strike(world, markedX, markedY, markedZ, 8, 24, 1.15);
                        world.spawnParticles(ParticleTypes.FLASH, markedX, markedY + 1, markedZ, 1, 0, 0, 0, 0);
                        playSound(SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 2.5f, 1.25f);
                    } else {
                        strike(world, markedX, markedY, markedZ, 11, 12, 1.45);
                        world.spawnParticles(ParticleTypes.END_ROD, markedX, markedY + 1, markedZ, 120, 3, 1, 3, 0.12);
                        playSound(SpartanBoss.DIVINE_SOUND, 2.5f, 1.05f);
                    }
                }
            } else if (sequenceAge == 48) {
                telegraph.start(markedX, markedY, markedZ, 11.0, 12);
            }
        } else if (sequence == 6) {
            if (telegraph.tick(world, new DustParticleEffect(0xFFF0A8, 1.35f))) {
                Vec3d markedDirection = new Vec3d(markedX - getX(), markedY - getY(), markedZ - getZ());
                ArenaEffects.crossfire(world, this, markedDirection, isPhaseTwoOrHigher() ? 20 : 16);
            }
        } else if (sequence == 2 && target != null && target.isAlive() && sequenceAge % 6 == 0) {
            shoot(world, target, CombatProjectileEntity.BOLT, isPhaseTwoOrHigher() ? 9 : 7);
        } else if ((sequence == 3 || sequence == 4) && sequenceAge % 12 == 0) {
            strike(world, getX(), getY(), getZ(), sequence == 3 ? 4 : 5, sequence == 3 ? 8 : 7, 0.4);
            if (sequence == 3) triggerAnim("movement", "execution");
            if (sequence == 3 && sequenceAge == 36) ArenaEffects.explosion(world, this, 2.0f);
        }
        if (sequenceAge >= sequenceDuration) {
            sequence = 0;
            sequenceTarget = null;
        }
    }

    private void shoot(ServerWorld world, LivingEntity target, int kind, float damage) {
        ItemStack visual = kind == CombatProjectileEntity.SPEAR ? new ItemStack(SpartanBoss.BLADES) : new ItemStack(Items.GOLD_NUGGET);
        CombatProjectileEntity.launch(world, this, visual, kind, target.getEyePos().subtract(getEyePos()), damage);
        world.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 1.5, getZ(), 16, 0.4, 0.4, 0.4, 0.08);
        playSound(SpartanBoss.DIVINE_SOUND, 1, 1.5f);
    }

    private void strike(ServerWorld world, double x, double y, double z, double radius, float damage, double knockback) {
        world.spawnParticles(ParticleTypes.END_ROD, x, y + 1, z, 80, radius / 2, 1, radius / 2, 0.1);
        Box box = new Box(x - radius, y - radius, z - radius, x + radius, y + radius, z + radius);
        for (PlayerEntity player : world.getEntitiesByClass(PlayerEntity.class, box, p -> p.isAlive() && !p.isCreative() && !p.isSpectator())) {
            double dx = player.getX() - x, dy = player.getY() - y, dz = player.getZ() - z;
            if (dx * dx + dy * dy + dz * dz > radius * radius) continue;
            player.damage(world, getDamageSources().mobAttack(this), damage * (isPhaseTwoOrHigher() ? 1.2f : 1));
            Vec3d direction = new Vec3d(dx, 0, dz).normalize();
            player.setVelocity(direction.x * knockback, 0.35, direction.z * knockback);
            player.velocityDirty = true;
        }
    }

    private void breakCobwebs(ServerWorld world) {
        for (BlockPos pos : BlockPos.iterateOutwards(getBlockPos(), 1, 2, 1)) {
            if (world.getBlockState(pos).isOf(Blocks.COBWEB) && getBoundingBox().intersects(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1, pos.getY() + 1, pos.getZ() + 1)) world.breakBlock(pos, true, this, 512);
        }
    }

    private boolean isPhaseTwoOrHigher() {
        return bossPhase.isAtLeast(BossPhase.PHASE_TWO);
    }

    private void updateBossPhase(ServerWorld world) {
        BossPhase next = BossPhaseManager.advance(bossPhase, getHealth(), getMaxHealth());
        if (next == bossPhase) return;
        bossPhase = next;
        applyPhaseSpeed();
        refreshPhasePresentation();
        if (bossPhase == BossPhase.PHASE_TWO) {
            world.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 1, getZ(), 100, 1, 1, 1, 0.12);
            playSound(SpartanBoss.DIVINE_SOUND, 2, 0.8f);
        } else if (bossPhase == BossPhase.PHASE_THREE) {
            world.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 1, getZ(), 180, 1.5, 1.5, 1.5, 0.16);
            playSound(SpartanBoss.DIVINE_SOUND, 2.5f, 1.15f);
        }
    }

    private void refreshPhasePresentation() {
        if (bossPhase == BossPhase.PHASE_THREE) {
            bar.setName(Text.literal("Gabriel – DIVINE ANNIHILATION"));
        } else if (bossPhase == BossPhase.PHASE_TWO) {
            bar.setName(Text.literal("Gabriel – Wrath of Heaven"));
        } else {
            bar.setName(Text.literal("Gabriel, The Judge of Heaven"));
        }
    }

    private void applyPhaseSpeed() {
        EntityAttributeInstance speed = getAttributeInstance(EntityAttributes.MOVEMENT_SPEED);
        if (speed != null) speed.setBaseValue(isPhaseTwoOrHigher() ? 0.46 : 0.38);
    }

    @Override public boolean damage(ServerWorld world, DamageSource source, float amount) {
        Entity attacker = source.getAttacker();
        if (dodgeCooldown == 0 && attacker instanceof PlayerEntity player
                && !player.isCreative() && !player.isSpectator() && getRandom().nextInt(100) < 15) {
            dodgeCooldown = 80;
            Vec3d dodgeVelocity = BossDodgeController.calculateVelocity(this, attacker, 0.9);
            setVelocity(dodgeVelocity.x, dodgeVelocity.y, dodgeVelocity.z);
            velocityDirty = true;
            playSound(SpartanBoss.DIVINE_SOUND, 1.0f, 1.7f);
            world.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 1, getZ(), 24, 0.55, 0.65, 0.55, 0.06);
            return false;
        }
        boolean damaged = super.damage(world, source, amount);
        if (damaged && damageVoiceCooldown == 0 && getRandom().nextFloat() < 0.35f) {
            playSound(SpartanBoss.GABRIEL_DAMAGE, 1.5f, 1.0f);
            damageVoiceCooldown = 55;
        }
        return damaged;
    }

    @Override protected float modifyAppliedDamage(DamageSource source, float amount) {
        float reduced = super.modifyAppliedDamage(source, amount);
        return source.isIn(DamageTypeTags.BYPASSES_EFFECTS) || source.isIn(DamageTypeTags.BYPASSES_ENCHANTMENTS)
            ? reduced : DamageUtil.getInflictedDamage(reduced, 16);
    }

    @Override public boolean handleFallDamage(double distance, float multiplier, DamageSource source) { return false; }
    @Override public void onDeath(DamageSource source) {
        if (!getEntityWorld().isClient()) {
            triggerAnim("movement", "death");
            playSound(SpartanBoss.GABRIEL_DEFEAT, 2.2f, 1.0f);
            dropItem(new ItemStack(SpartanBoss.BLADES), true, false);
            dropItem(new ItemStack(SpartanBoss.BLADES), true, false);
        }
        super.onDeath(source);
    }
    @Override public boolean tryAttack(ServerWorld world, Entity target) {
        triggerAnim("movement", "attack");
        return super.tryAttack(world, target);
    }
    @Override public void onStartedTrackingBy(ServerPlayerEntity player) { super.onStartedTrackingBy(player); bar.addPlayer(player); }
    @Override public void onStoppedTrackingBy(ServerPlayerEntity player) { super.onStoppedTrackingBy(player); bar.removePlayer(player); }
    @Override protected void readCustomData(ReadView view) {
        super.readCustomData(view);
        bossPhase = BossPhaseManager.read(view, getHealth(), getMaxHealth());
        flightCooldown = view.getInt("FlightCooldown", 200);
        ultimateCooldown = view.getInt("UltimateCooldown", 0);
        dodgeCooldown = view.getInt("DodgeCooldown", 0);
        ambientVoiceCooldown = view.getInt("AmbientVoiceCooldown", 0);
        damageVoiceCooldown = view.getInt("DamageVoiceCooldown", 0);
        summonVoicePlayed = view.getBoolean("SummonVoicePlayed", false);
        telegraph.clear();
        flightTicks = Math.max(0, Math.min(100, view.getInt("FlightTicks", 0)));
        crashing = view.getBoolean("Crashing", false);
        combatState.setAttackCooldown(view.getInt("AttackCooldown", 100));
        for (int i = 0; i < combatState.getAbilityCount(); i++) combatState.setAbilityCooldown(i, view.getInt("AbilityCooldown" + i, 0));
        getDataTracker().set(FLYING, flightTicks > 0);
        setNoGravity(flightTicks > 0);
        applyPhaseSpeed();
        refreshPhasePresentation();
    }
    @Override protected void writeCustomData(WriteView view) {
        super.writeCustomData(view);
        BossPhaseManager.write(view, bossPhase);
        view.putInt("FlightCooldown", flightCooldown);
        view.putInt("UltimateCooldown", ultimateCooldown);
        view.putInt("DodgeCooldown", dodgeCooldown);
        view.putInt("AmbientVoiceCooldown", ambientVoiceCooldown);
        view.putInt("DamageVoiceCooldown", damageVoiceCooldown);
        view.putBoolean("SummonVoicePlayed", summonVoicePlayed);
        view.putInt("FlightTicks", flightTicks);
        view.putBoolean("Crashing", crashing);
        view.putInt("AttackCooldown", combatState.getAttackCooldown());
        for (int i = 0; i < combatState.getAbilityCount(); i++) view.putInt("AbilityCooldown" + i, combatState.getAbilityCooldown(i));
    }
    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<GabrielEntity>("movement", 5, state -> state.setAndContinue(RawAnimation.begin().thenLoop(
                state.animatable() instanceof GabrielEntity gabriel && gabriel.isFlying() ? "animation.gabriel.fly" : state.isMoving() ? "animation.gabriel.walk" : "animation.gabriel.idle")))
            .triggerableAnim("attack", RawAnimation.begin().thenPlay("animation.gabriel.attack"))
            .triggerableAnim("spear", RawAnimation.begin().thenPlay("animation.gabriel.spear"))
            .triggerableAnim("judgment", RawAnimation.begin().thenPlay("animation.gabriel.judgment"))
            .triggerableAnim("barrage", RawAnimation.begin().thenPlay("animation.gabriel.barrage"))
            .triggerableAnim("execution", RawAnimation.begin().thenPlay("animation.gabriel.execution"))
            .triggerableAnim("crossfire", RawAnimation.begin().thenPlay("animation.gabriel.crossfire"))
            .triggerableAnim("ultimate", RawAnimation.begin().thenPlay("animation.gabriel.ultimate"))
            .triggerableAnim("dive", RawAnimation.begin().thenPlay("animation.gabriel.dive"))
            .triggerableAnim("death", RawAnimation.begin().thenPlay("animation.gabriel.death")));
    }
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}