package com.kodari.spartanboss;

import net.minecraft.particle.ParticleEffect;
import net.minecraft.server.world.ServerWorld;

/** Shared server-side warning marker used before high-impact boss attacks. */
public final class BossTelegraph {
    private int ticksRemaining;
    private double x;
    private double y;
    private double z;
    private double radius;

    public void start(double x, double y, double z, double radius, int duration) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.radius = Math.max(0.5, radius);
        this.ticksRemaining = Math.max(1, duration);
    }

    /** Draws the warning ring and returns true on the exact tick it completes. */
    public boolean tick(ServerWorld world, ParticleEffect particle) {
        if (!isActive()) return false;

        int points = Math.max(24, (int) Math.ceil(radius * 8.0));
        for (int i = 0; i < points; i++) {
            double angle = (Math.PI * 2.0 * i) / points;
            double px = x + Math.cos(angle) * radius;
            double pz = z + Math.sin(angle) * radius;
            world.spawnParticles(particle, px, y + 0.12, pz, 1, 0.015, 0.015, 0.015, 0.0);
        }

        ticksRemaining--;
        return ticksRemaining == 0;
    }

    public boolean isActive() {
        return ticksRemaining > 0;
    }

    public void clear() {
        ticksRemaining = 0;
    }
}
