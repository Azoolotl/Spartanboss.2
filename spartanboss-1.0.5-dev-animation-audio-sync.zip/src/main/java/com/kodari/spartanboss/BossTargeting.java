package com.kodari.spartanboss;

import java.util.Comparator;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;

/** Keeps boss target selection stable in multiplayer instead of rapidly switching players. */
public final class BossTargeting {
    private BossTargeting() {}

    public static LivingEntity retainOrAcquire(HostileEntity boss, ServerWorld world, double range) {
        LivingEntity current = boss.getTarget();
        if (isValidTarget(boss, current, range)) return current;

        PlayerEntity replacement = world.getEntitiesByClass(PlayerEntity.class,
                boss.getBoundingBox().expand(range), player -> isValidTarget(boss, player, range))
            .stream()
            .min(Comparator.comparingDouble(boss::squaredDistanceTo))
            .orElse(null);
        boss.setTarget(replacement);
        return replacement;
    }

    private static boolean isValidTarget(HostileEntity boss, LivingEntity target, double range) {
        return target instanceof PlayerEntity player
            && player.isAlive()
            && !player.isCreative()
            && !player.isSpectator()
            && boss.squaredDistanceTo(player) <= range * range;
    }
}
