package com.kodari.spartanboss;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public final class WeaponAbilitySequences {
    private static final Map<UUID, ChaosCombo> CHAOS_COMBOS = new HashMap<>();
    private static final Map<UUID, Integer> RAGE_TICKS = new HashMap<>();
    private static final Map<UUID, Stun> STUNS = new HashMap<>();
    private static final List<FrostField> FROST_FIELDS = new ArrayList<>();
    private static final Map<UUID, DivineDash> DIVINE_DASHES = new HashMap<>();
    private static final Map<UUID, HeavenlyCrash> HEAVENLY_CRASHES = new HashMap<>();

    private WeaponAbilitySequences() { throw new AssertionError(); }

    public static void initialize() {
        ServerTickEvents.END_SERVER_TICK.register(WeaponAbilitySequences::tick);
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((target, source, amount) ->
            !isStunned(source.getAttacker()) && !(source.isOf(DamageTypes.FALL) && HEAVENLY_CRASHES.containsKey(target.getUuid())));
        AttackEntityCallback.EVENT.register((player, world, hand, target, hit) -> actionResult(player, world));
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> actionResult(player, world));
        UseItemCallback.EVENT.register((player, world, hand) -> actionResult(player, world));
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> actionResult(player, world));
        UseEntityCallback.EVENT.register((player, world, hand, target, hit) -> actionResult(player, world));
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            CHAOS_COMBOS.clear();
            RAGE_TICKS.clear();
            STUNS.clear();
            FROST_FIELDS.clear();
            DIVINE_DASHES.clear();
            HEAVENLY_CRASHES.clear();
        });
    }

    public static void startChaosCombo(ServerWorld world, PlayerEntity user, Hand hand, ItemStack stack) {
        float damage;
        if (hand == Hand.MAIN_HAND) {
            damage = (float) user.getAttributeValue(EntityAttributes.ATTACK_DAMAGE);
        } else {
            double[] amount = {1.0};
            stack.applyAttributeModifiers(EquipmentSlot.MAINHAND, (attribute, modifier) -> {
                if (attribute.equals(EntityAttributes.ATTACK_DAMAGE) && modifier.operation() == EntityAttributeModifier.Operation.ADD_VALUE) {
                    amount[0] += modifier.value();
                }
            });
            damage = (float) amount[0];
        }
        chaosSlash(world, user, damage);
        CHAOS_COMBOS.put(user.getUuid(), new ChaosCombo(world, hand, damage));
    }

    public static void startRage(PlayerEntity user) {
        RAGE_TICKS.put(user.getUuid(), 120);
    }

    public static boolean isStunned(Entity entity) {
        return entity != null && STUNS.containsKey(entity.getUuid());
    }

    private static ActionResult actionResult(PlayerEntity player, World world) {
        return world instanceof ServerWorld && isStunned(player) ? ActionResult.FAIL : ActionResult.PASS;
    }

    public static void stunNearby(ServerWorld world, PlayerEntity user) {
        ArenaEffects.ring(world, user, ParticleTypes.SNOWFLAKE, 5, 64);
        world.spawnParticles(ParticleTypes.SNOWFLAKE, user.getX(), user.getY() + 1, user.getZ(), 90, 2.2, 0.8, 2.2, 0.08);
        user.playSound(SpartanBoss.FROST_SOUND, 1.8f, 0.7f);
        for (LivingEntity target : world.getEntitiesByClass(LivingEntity.class, user.getBoundingBox().expand(5),
                entity -> entity != user && entity.isAlive() && !entity.isSpectator()
                    && (!(entity instanceof PlayerEntity player) || (!player.isCreative() && user.shouldDamagePlayer(player))))) {
            if (user.squaredDistanceTo(target) > 25) continue;
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 5, false, false, false), user);
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 80, 2, false, false, false), user);
            STUNS.put(target.getUuid(), new Stun(world, target.getEntityPos()));
        }
    }

    public static void createFrostSpikes(ServerWorld world, PlayerEntity user) {
        Vec3d forward = Vec3d.fromPolar(0, user.getYaw());
        Vec3d side = new Vec3d(-forward.z, 0, forward.x);
        List<BlockPos> positions = new ArrayList<>();
        for (int distance = 2; distance <= 8; distance += 2) {
            for (int lane = -1; lane <= 1; lane++) {
                Vec3d point = user.getEntityPos().add(forward.multiply(distance)).add(side.multiply(lane * 1.25));
                BlockPos base = BlockPos.ofFloored(point.x, point.y, point.z);
                for (int height = 1; height >= -2; height--) {
                    BlockPos candidate = base.up(height);
                    if (world.getBlockState(candidate).isAir() && !world.getBlockState(candidate.down()).isAir()) {
                        if (placeSpike(world, candidate, positions) && distance % 4 == 0) {
                            placeSpike(world, candidate.up(), positions);
                        }
                        break;
                    }
                }
            }
        }
        if (!positions.isEmpty()) FROST_FIELDS.add(new FrostField(world, user.getUuid(), positions));
        user.playSound(SpartanBoss.FROST_SOUND, 1.8f, 0.85f);
    }

    private static boolean placeSpike(ServerWorld world, BlockPos pos, List<BlockPos> positions) {
        if (!world.getBlockState(pos).isAir()
                || !world.getEntitiesByClass(LivingEntity.class, new Box(pos), LivingEntity::isAlive).isEmpty()
                || !world.setBlockState(pos, SpartanBoss.TEMPORARY_ICE.getDefaultState())) return false;
        positions.add(pos);
        world.spawnParticles(ParticleTypes.SNOWFLAKE, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
            12, 0.35, 0.4, 0.35, 0.04);
        return true;
    }

    public static void startDivineDash(ServerWorld world, PlayerEntity user) {
        Vec3d direction = Vec3d.fromPolar(0, user.getYaw()).normalize();
        DIVINE_DASHES.put(user.getUuid(), new DivineDash(world, user.getEntityPos(), direction));
        Vec3d previous = user.getVelocity();
        user.setVelocity(direction.x * 2.2 + previous.x * 0.25, Math.max(0.18, previous.y), direction.z * 2.2 + previous.z * 0.25);
        syncVelocity(user);
        world.spawnParticles(ParticleTypes.END_ROD, user.getX(), user.getY() + 1, user.getZ(), 30, 0.4, 0.6, 0.4, 0.1);
        user.playSound(SpartanBoss.DIVINE_SOUND, 1.6f, 1.4f);
    }

    public static void startHeavenlyCrash(ServerWorld world, PlayerEntity user) {
        HEAVENLY_CRASHES.put(user.getUuid(), new HeavenlyCrash(world, user.getY() + 10));
        user.fallDistance = 0;
        Vec3d previous = user.getVelocity();
        user.setVelocity(previous.x * 0.25, 0.55, previous.z * 0.25);
        syncVelocity(user);
        world.spawnParticles(ParticleTypes.END_ROD, user.getX(), user.getY() + 0.5, user.getZ(), 30, 0.5, 0.2, 0.5, 0.08);
        user.playSound(SpartanBoss.DIVINE_SOUND, 1.6f, 0.9f);
    }

    private static void tick(MinecraftServer server) {
        Iterator<Map.Entry<UUID, ChaosCombo>> combos = CHAOS_COMBOS.entrySet().iterator();
        while (combos.hasNext()) {
            Map.Entry<UUID, ChaosCombo> entry = combos.next();
            ChaosCombo combo = entry.getValue();
            ServerPlayerEntity user = server.getPlayerManager().getPlayer(entry.getKey());
            if (user == null || !user.isAlive() || isStunned(user) || user.getEntityWorld() != combo.world
                    || !user.getStackInHand(combo.hand).isOf(SpartanBoss.CHAOS_BLADES)) {
                combos.remove();
                continue;
            }
            combo.age++;
            if (combo.age == 12 || combo.age == 24) {
                chaosSlash(combo.world, user, combo.damage);
                user.swingHand(combo.hand, true);
            }
            if (combo.age >= 24) combos.remove();
        }

        Iterator<Map.Entry<UUID, Integer>> rages = RAGE_TICKS.entrySet().iterator();
        while (rages.hasNext()) {
            Map.Entry<UUID, Integer> entry = rages.next();
            ServerPlayerEntity user = server.getPlayerManager().getPlayer(entry.getKey());
            int ticks = entry.getValue() - 1;
            if (user == null || !user.isAlive() || !user.hasStatusEffect(StatusEffects.STRENGTH) || ticks <= 0) {
                rages.remove();
                continue;
            }
            entry.setValue(ticks);
            if (ticks % 5 == 0) {
                user.getEntityWorld().spawnParticles(new DustParticleEffect(0xE51C10, 1.2f),
                    user.getX(), user.getY() + 1, user.getZ(), 12, 0.45, 0.65, 0.45, 0.03);
            }
        }
        tickDivineDashes(server);
        tickHeavenlyCrashes(server);
        tickStuns();
        tickFrostFields(server);
    }

    private static void tickDivineDashes(MinecraftServer server) {
        Iterator<Map.Entry<UUID, DivineDash>> iterator = DIVINE_DASHES.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, DivineDash> entry = iterator.next();
            DivineDash dash = entry.getValue();
            ServerPlayerEntity user = server.getPlayerManager().getPlayer(entry.getKey());
            if (user == null || !user.isAlive() || isStunned(user) || user.getEntityWorld() != dash.world) {
                iterator.remove();
                continue;
            }
            Vec3d current = user.getEntityPos();
            Vec3d from = dash.previous.add(0, user.getHeight() * 0.5, 0);
            Vec3d to = current.add(0, user.getHeight() * 0.5, 0);
            Box path = user.getBoundingBox().stretch(dash.previous.subtract(current)).expand(0.7);
            for (LivingEntity target : dash.world.getEntitiesByClass(LivingEntity.class, path,
                    entity -> entity != user && entity.isAlive() && !entity.isSpectator() && !user.isTeammate(entity)
                        && (!(entity instanceof PlayerEntity player) || (!player.isCreative() && user.shouldDamagePlayer(player))))) {
                if (dash.hits.contains(target.getUuid())) continue;
                Box hitbox = target.getBoundingBox().expand(user.getWidth() * 0.5 + 0.35);
                if (!hitbox.contains(from) && hitbox.raycast(from, to).isEmpty()) continue;
                dash.hits.add(target.getUuid());
                target.takeKnockback(1.8, -dash.direction.x, -dash.direction.z);
                syncVelocity(target);
                dash.world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY() + 1, target.getZ(),
                    12, 0.3, 0.4, 0.3, 0.04);
            }
            dash.world.spawnParticles(ParticleTypes.END_ROD, user.getX(), user.getY() + 0.8, user.getZ(), 5, 0.25, 0.4, 0.25, 0.03);
            dash.previous = current;
            if (++dash.ticks >= 12) iterator.remove();
        }
    }

    private static void tickHeavenlyCrashes(MinecraftServer server) {
        Iterator<Map.Entry<UUID, HeavenlyCrash>> iterator = HEAVENLY_CRASHES.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, HeavenlyCrash> entry = iterator.next();
            HeavenlyCrash crash = entry.getValue();
            ServerPlayerEntity user = server.getPlayerManager().getPlayer(entry.getKey());
            if (user == null || !user.isAlive() || isStunned(user) || user.getEntityWorld() != crash.world) {
                iterator.remove();
                continue;
            }
            user.fallDistance = 0;
            if (crash.stage == 0) {
                if (user.getY() > crash.maxY) user.requestTeleport(user.getX(), crash.maxY, user.getZ());
                double remaining = crash.maxY - user.getY();
                double step = Math.min(0.55, Math.max(0, remaining));
                if (remaining <= 0.05 || ++crash.stageTicks >= 60
                        || !crash.world.isSpaceEmpty(user, user.getBoundingBox().offset(0, step, 0))) {
                    crash.stage = 1;
                    crash.stageTicks = 0;
                    crash.hoverY = Math.min(user.getY(), crash.maxY);
                    user.setVelocity(0, 0, 0);
                } else {
                    Vec3d velocity = user.getVelocity();
                    user.setVelocity(velocity.x * 0.6, step, velocity.z * 0.6);
                }
                syncVelocity(user);
                crash.world.spawnParticles(ParticleTypes.END_ROD, user.getX(), user.getY() + 0.4, user.getZ(), 5, 0.4, 0.2, 0.4, 0.02);
            } else if (crash.stage == 1) {
                if (Math.abs(user.getY() - crash.hoverY) > 0.1) user.requestTeleport(user.getX(), crash.hoverY, user.getZ());
                user.setVelocity(0, 0, 0);
                if (++crash.stageTicks >= 14) {
                    crash.stage = 2;
                    crash.stageTicks = 0;
                    user.setVelocity(0, -1.35, 0);
                    user.playSound(SpartanBoss.DIVINE_SOUND, 1.5f, 1.6f);
                }
                syncVelocity(user);
                crash.world.spawnParticles(ParticleTypes.END_ROD, user.getX(), user.getY() + 0.8, user.getZ(), 8, 0.5, 0.5, 0.5, 0.04);
            } else {
                crash.stageTicks++;
                if (user.isOnGround() || !crash.world.isSpaceEmpty(user, user.getBoundingBox().offset(0, -0.1, 0))) {
                    heavenlyImpact(crash.world, user);
                    iterator.remove();
                    continue;
                }
                if (crash.stageTicks >= 100) {
                    iterator.remove();
                    continue;
                }
                Vec3d velocity = user.getVelocity();
                user.setVelocity(velocity.x * 0.8, -1.35, velocity.z * 0.8);
                syncVelocity(user);
                crash.world.spawnParticles(ParticleTypes.END_ROD, user.getX(), user.getY() + 1, user.getZ(), 10, 0.4, 0.7, 0.4, 0.06);
            }
        }
    }

    private static void heavenlyImpact(ServerWorld world, PlayerEntity user) {
        double radius = GabrielEntity.CRASH_RADIUS;
        ArenaEffects.ring(world, user, ParticleTypes.END_ROD, radius, 64);
        world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, user.getX(), user.getY() + 0.5, user.getZ(), 1, 0, 0, 0, 0);
        world.spawnParticles(ParticleTypes.END_ROD, user.getX(), user.getY() + 1, user.getZ(), 100, 2.5, 1, 2.5, 0.15);
        for (LivingEntity target : world.getEntitiesByClass(LivingEntity.class, user.getBoundingBox().expand(radius),
                entity -> entity != user && entity.isAlive() && !entity.isSpectator() && !user.isTeammate(entity))) {
            if (user.squaredDistanceTo(target) > radius * radius) continue;
            if (target.damage(world, user.getDamageSources().playerAttack(user), GabrielEntity.CRASH_DAMAGE)) {
                target.takeKnockback(1.4, user.getX() - target.getX(), user.getZ() - target.getZ());
                syncVelocity(target);
            }
        }
        ArenaEffects.explosion(world, user, GabrielEntity.CRASH_EXPLOSION_POWER);
        user.playSound(SpartanBoss.CRASH_SOUND, 2.5f, 0.8f);
    }

    private static void syncVelocity(Entity entity) {
        entity.velocityDirty = true;
        if (entity instanceof ServerPlayerEntity player) player.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(player));
    }

    private static void tickStuns() {
        Iterator<Map.Entry<UUID, Stun>> iterator = STUNS.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Stun> entry = iterator.next();
            Stun stun = entry.getValue();
            Entity entity = stun.world.getEntity(entry.getKey());
            if (!(entity instanceof LivingEntity target) || !target.isAlive() || --stun.ticks <= 0) {
                iterator.remove();
                continue;
            }
            if (target instanceof MobEntity mob) mob.getNavigation().stop();
            stun.y = Math.min(stun.y, target.getY());
            double dx = target.getX() - stun.x;
            double dz = target.getZ() - stun.z;
            if (dx * dx + dz * dz > 0.0025 || target.getY() > stun.y + 0.05) {
                target.requestTeleport(stun.x, stun.y, stun.z);
            }
            target.setVelocity(0, Math.min(0, target.getVelocity().y), 0);
            syncVelocity(target);
            if (stun.ticks % 5 == 0) {
                stun.world.spawnParticles(ParticleTypes.SNOWFLAKE, target.getX(), target.getY() + 1, target.getZ(),
                    6, 0.35, 0.55, 0.35, 0.01);
            }
        }
    }

    private static void tickFrostFields(MinecraftServer server) {
        Iterator<FrostField> iterator = FROST_FIELDS.iterator();
        while (iterator.hasNext()) {
            FrostField field = iterator.next();
            if (++field.age >= 120) {
                iterator.remove();
                continue;
            }
            if (field.age % 5 != 0) continue;
            ServerPlayerEntity owner = server.getPlayerManager().getPlayer(field.owner);
            DamageSource source = owner != null && owner.getEntityWorld() == field.world
                ? owner.getDamageSources().playerAttack(owner) : field.world.getDamageSources().freeze();
            Set<UUID> checked = new HashSet<>();
            for (BlockPos pos : field.positions) {
                if (!field.world.getBlockState(pos).isOf(SpartanBoss.TEMPORARY_ICE)) continue;
                for (LivingEntity target : field.world.getEntitiesByClass(LivingEntity.class, new Box(pos).expand(0.22),
                        entity -> entity.isAlive() && !entity.isSpectator() && !entity.getUuid().equals(field.owner))) {
                    UUID id = target.getUuid();
                    if (!checked.add(id) || field.nextHit.getOrDefault(id, 0) > field.age) continue;
                    if (target.damage(field.world, source, 4)) {
                        target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 1));
                        field.nextHit.put(id, field.age + 20);
                        field.world.spawnParticles(ParticleTypes.SNOWFLAKE, target.getX(), target.getY() + 0.8, target.getZ(),
                            10, 0.3, 0.4, 0.3, 0.03);
                    }
                }
            }
        }
    }

    private static void chaosSlash(ServerWorld world, PlayerEntity user, float damage) {
        Vec3d facing = user.getRotationVec(1).normalize();
        Vec3d horizontal = new Vec3d(facing.x, 0, facing.z).normalize();
        Vec3d side = new Vec3d(-horizontal.z, 0, horizontal.x);
        for (int i = 0; i <= 20; i++) {
            double angle = (i / 20.0 - 0.5) * Math.PI * 0.8;
            Vec3d point = user.getEyePos().add(horizontal.multiply(Math.cos(angle) * 3))
                .add(side.multiply(Math.sin(angle) * 3));
            world.spawnParticles(ParticleTypes.FLAME, point.x, point.y, point.z, 2, 0.06, 0.1, 0.06, 0.01);
        }
        Vec3d sweep = user.getEyePos().add(facing.multiply(2));
        world.spawnParticles(ParticleTypes.SWEEP_ATTACK, sweep.x, sweep.y, sweep.z, 1, 0, 0, 0, 0);
        for (LivingEntity target : world.getEntitiesByClass(LivingEntity.class, user.getBoundingBox().expand(4.5),
                entity -> entity != user && entity.isAlive() && !entity.isSpectator() && !user.isTeammate(entity))) {
            Vec3d offset = target.getEyePos().subtract(user.getEyePos());
            if (offset.length() > 4.5 || offset.normalize().dotProduct(facing) < 0.2) continue;
            if (target.damage(world, user.getDamageSources().playerAttack(user), damage)) {
                target.setOnFireFor(4);
                double strength = Math.max(0, 1 - target.getAttributeValue(EntityAttributes.KNOCKBACK_RESISTANCE));
                Vec3d direction = new Vec3d(offset.x, 0, offset.z).normalize();
                Vec3d velocity = target.getVelocity();
                target.setVelocity(velocity.x + direction.x * 0.3 * strength,
                    Math.max(velocity.y, 0.65 * strength), velocity.z + direction.z * 0.3 * strength);
                syncVelocity(target);
            }
        }
        user.playSound(SpartanBoss.CHAIN_SOUND, 1.2f, 1.05f);
    }

    private static final class ChaosCombo {
        private final ServerWorld world;
        private final Hand hand;
        private final float damage;
        private int age;

        private ChaosCombo(ServerWorld world, Hand hand, float damage) {
            this.world = world;
            this.hand = hand;
            this.damage = damage;
        }
    }

    private static final class Stun {
        private final ServerWorld world;
        private final double x;
        private final double z;
        private double y;
        private int ticks = 80;

        private Stun(ServerWorld world, Vec3d position) {
            this.world = world;
            this.x = position.x;
            this.y = position.y;
            this.z = position.z;
        }
    }

    private static final class DivineDash {
        private final ServerWorld world;
        private final Vec3d direction;
        private final Set<UUID> hits = new HashSet<>();
        private Vec3d previous;
        private int ticks;

        private DivineDash(ServerWorld world, Vec3d position, Vec3d direction) {
            this.world = world;
            this.previous = position;
            this.direction = direction;
        }
    }

    private static final class HeavenlyCrash {
        private final ServerWorld world;
        private final double maxY;
        private double hoverY;
        private int stage;
        private int stageTicks;

        private HeavenlyCrash(ServerWorld world, double maxY) {
            this.world = world;
            this.maxY = maxY;
        }
    }

    private static final class FrostField {
        private final ServerWorld world;
        private final UUID owner;
        private final List<BlockPos> positions;
        private final Map<UUID, Integer> nextHit = new HashMap<>();
        private int age;

        private FrostField(ServerWorld world, UUID owner, List<BlockPos> positions) {
            this.world = world;
            this.owner = owner;
            this.positions = positions;
        }
    }
}