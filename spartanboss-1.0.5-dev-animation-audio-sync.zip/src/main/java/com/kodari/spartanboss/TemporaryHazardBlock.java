package com.kodari.spartanboss;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCollisionHandler;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

public class TemporaryHazardBlock extends Block {
    private final boolean burning;

    public TemporaryHazardBlock(Settings settings, boolean burning) {
        super(settings);
        this.burning = burning;
    }

    @Override
    protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
        super.onBlockAdded(state, world, pos, oldState, notify);
        if (!world.isClient() && !oldState.isOf(this)) world.scheduleBlockTick(pos, this, burning ? 80 : 120);
    }

    @Override
    protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        if (world.getBlockState(pos).isOf(this)) world.removeBlock(pos, false);
    }

    @Override
    protected void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity, EntityCollisionHandler handler, boolean moved) {
        if (burning && !world.isClient()) entity.setOnFireFor(2);
    }
}