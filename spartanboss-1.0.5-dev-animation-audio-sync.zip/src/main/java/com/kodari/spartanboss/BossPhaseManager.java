package com.kodari.spartanboss;

import net.minecraft.storage.ReadView;
import net.minecraft.storage.WriteView;

/** Shared persistence and transition rules for boss phase progression. */
public final class BossPhaseManager {
    private BossPhaseManager() {}

    /**
     * Advances a boss according to the agreed 70% / 35% health thresholds.
     * Phase progression is intentionally monotonic: healing cannot downgrade a boss.
     */
    public static BossPhase advance(BossPhase current, float health, float maxHealth) {
        BossPhase healthPhase = BossPhase.fromHealth(health, maxHealth);
        return current.ordinal() >= healthPhase.ordinal() ? current : healthPhase;
    }

    /**
     * Reads the new phase value while accepting old saves that only stored PhaseTwo.
     * The higher of saved progress and current health-derived progress is retained.
     */
    public static BossPhase read(ReadView view, float health, float maxHealth) {
        int legacyPhase = view.getBoolean("PhaseTwo", false) ? 2 : 1;
        int storedPhase = view.getInt("BossPhase", legacyPhase);
        return advance(BossPhase.fromId(storedPhase), health, maxHealth);
    }

    public static void write(WriteView view, BossPhase phase) {
        view.putInt("BossPhase", phase.getId());
        // Retain the legacy field so older builds can still interpret the save.
        view.putBoolean("PhaseTwo", phase.isAtLeast(BossPhase.PHASE_TWO));
    }
}
