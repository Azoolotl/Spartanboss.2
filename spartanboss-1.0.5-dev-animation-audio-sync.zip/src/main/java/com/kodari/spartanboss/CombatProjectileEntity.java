package com.kodari.spartanboss;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.FlyingItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

public class CombatProjectileEntity extends ProjectileEntity implements FlyingItemEntity {
    public static final int AXE = 0;
    public static final int SPEAR = 1;
    public static final int BOLT = 2;
    public static final int SLASH_LEFT = 3;
    public static final int SLASH_RIGHT = 4;
    private static final TrackedData<ItemStack> ITEM = DataTracker.registerData(CombatProjectileEntity.class, TrackedDataHandlerRegistry.ITEM_STACK);
    private final Set<UUID> outwardHits = new HashSet<>();
    private final Set<UUID> returnHits = new HashSet<>();
    private int kind;
    private float damage;
    private boolean returning;

    public CombatProjectileEntity(EntityType<? extends CombatProjectileEntity> type, World world) {
        super(type, world);
        setNoGravity(true);
    }

    public static boolean launch(ServerWorld world, LivingEntity owner, ItemStack stack, int kind, Vec3d direction, float damage) {
        return launch(world, owner, stack, kind, direction, damage, new Vec3d(0, 0, 0));
    }

    public static boolean launch(ServerWorld world, LivingEntity owner, ItemStack stack, int kind, Vec3d direction, float damage, Vec3d offset) {
        CombatProjectileEntity projectile = new CombatProjectileEntity(SpartanBoss.PROJECTILE, world);
        Vec3d aim = direction.normalize();
        projectile.kind = kind;
        projectile.damage = damage;
        projectile.setOwner(owner);
        projectile.getDataTracker().set(ITEM, stack.copy());
        projectile.setPosition(owner.getEyePos().add(offset).add(aim.multiply(0.8)));
        projectile.setVelocity(aim.multiply(kind == AXE ? 1.35 : 1.55));
        return world.spawnEntity(projectile);
    }

    @Override protected void initDataTracker(DataTracker.Builder builder) { builder.add(ITEM, new ItemStack(Items.SNOWBALL)); }
    @Override public ItemStack getStack() { return getDataTracker().get(ITEM); }

    @Override
    public void tick() {
        super.tick();
        if (!(getEntityWorld() instanceof ServerWorld world)) return;
        Entity owner = getOwner();
        int maxAge = kind == AXE ? 100 : kind >= SLASH_LEFT ? 24 : 45;
        if (!(owner instanceof LivingEntity livingOwner) || !livingOwner.isAlive() || age > maxAge) {
            finish();
            return;
        }
        if (kind == AXE && (returning || age >= 16)) {
            returning = true;
            Vec3d back = livingOwner.getEyePos().subtract(getEntityPos());
            if (back.length() < 1.5) {
                playSound(SoundEvents.BLOCK_CHAIN_HIT, 0.8f, 1.5f);
                finish();
                return;
            }
            setVelocity(back.normalize().multiply(1.6));
        }
        Vec3d from = getEntityPos();
        Vec3d to = from.add(getVelocity());
        BlockHitResult blockHit = returning ? null : world.raycast(new RaycastContext(from, to,
            RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, this));
        boolean blocked = blockHit != null && blockHit.getType() != HitResult.Type.MISS;
        if (blocked) to = blockHit.getPos();
        Set<UUID> alreadyHit = returning ? returnHits : outwardHits;
        Box sweep = new Box(from.x, from.y, from.z, to.x, to.y, to.z).expand(kind >= SLASH_LEFT ? 2.0 : 1.0);
        for (LivingEntity target : world.getEntitiesByClass(LivingEntity.class, sweep,
                e -> e != owner && e.isAlive() && !alreadyHit.contains(e.getUuid())
                    && (!(e instanceof PlayerEntity p) || (!p.isCreative() && !p.isSpectator()))
                    && (owner instanceof PlayerEntity || e instanceof PlayerEntity))) {
            Box hitbox = target.getBoundingBox().expand(kind >= SLASH_LEFT ? 1.1 : 0.35);
            if (!hitbox.contains(from) && hitbox.raycast(from, to).isEmpty()) continue;
            alreadyHit.add(target.getUuid());
            target.damage(world, getDamageSources().thrown(this, owner), damage);
            if (kind == AXE) {
                target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1));
                world.spawnParticles(ParticleTypes.SNOWFLAKE, target.getX(), target.getY() + 1, target.getZ(), 28, 0.7, 0.7, 0.7, 0.03);
                playSound(SpartanBoss.FROST_SOUND, 1.0f, 1.1f);
            }
            if (kind == SPEAR) target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 30, 6));
            if (kind == SPEAR || kind == BOLT) {
                world.spawnParticles(ParticleTypes.END_ROD, target.getX(), target.getY() + 1, target.getZ(), 24, 0.4, 0.6, 0.4, 0.08);
                finish();
                return;
            }
        }
        setPosition(to);
        velocityDirty = true;
        world.spawnParticles(kind == AXE ? ParticleTypes.SNOWFLAKE : ParticleTypes.END_ROD,
            to.x, to.y, to.z, kind == AXE ? 6 : 4, 0.15, 0.15, 0.15, 0.02);
        if (kind >= SLASH_LEFT) {
            Vec3d direction = getVelocity().normalize();
            Vec3d side = new Vec3d(-direction.z, 0, direction.x).normalize();
            int sign = kind == SLASH_LEFT ? 1 : -1;
            for (int i = -5; i <= 5; i++) {
                Vec3d point = to.add(side.multiply(i * 0.35)).add(0, sign * i * 0.35, 0);
                world.spawnParticles(new DustParticleEffect(0xFFD967, 1.3f), point.x, point.y, point.z, 1, 0.02, 0.02, 0.02, 0);
            }
        }
        if (blocked) {
            world.spawnParticles(kind == AXE ? ParticleTypes.SNOWFLAKE : ParticleTypes.EXPLOSION,
                to.x, to.y, to.z, kind == AXE ? 35 : 1, 0.6, 0.6, 0.6, 0.04);
            playSound(kind == AXE ? SoundEvents.BLOCK_GLASS_BREAK : SoundEvents.BLOCK_BELL_RESONATE, 1.2f, 1.2f);
            if (kind == AXE) returning = true;
            else finish();
        }
    }

    private void finish() {
        if (kind == AXE && getOwner() instanceof SpartanEntity spartan) spartan.onAxeReturned();
        discard();
    }
}