package com.kodari.spartanboss;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;

/** Calculates a small, bounded evasive impulse for a boss avoiding an incoming player hit. */
public final class BossDodgeController {
    private BossDodgeController() {}

    public static Vec3d calculateVelocity(Entity boss, Entity attacker, double strength) {
        Vec3d away = boss.getEntityPos().subtract(attacker.getEntityPos());
        away = new Vec3d(away.x, 0.0, away.z);
        if (away.lengthSquared() < 1.0E-4) {
            Vec3d facing = boss.getRotationVec(1.0f);
            away = new Vec3d(-facing.x, 0.0, -facing.z);
            if (away.lengthSquared() < 1.0E-4) away = new Vec3d(0.0, 0.0, 1.0);
        }
        away = away.normalize();
        Vec3d lateral = new Vec3d(-away.z, 0.0, away.x).multiply(strength * 0.28);
        Vec3d movement = away.multiply(strength).add(lateral);
        return new Vec3d(movement.x, Math.max(0.12, boss.getVelocity().y), movement.z);
    }
}
