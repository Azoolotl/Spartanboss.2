package com.kodari.spartanboss;

import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.rule.GameRules;

public final class ArenaEffects {
    private ArenaEffects() { throw new AssertionError(); }

    public static void ring(ServerWorld world, LivingEntity source, ParticleEffect effect, double radius, int points) {
        for (int i = 0; i < points; i++) {
            double angle = Math.PI * 2 * i / points;
            world.spawnParticles(effect, source.getX() + Math.cos(angle) * radius, source.getY() + 0.25,
                source.getZ() + Math.sin(angle) * radius, 1, 0.04, 0.08, 0.04, 0.01);
        }
    }

    public static void explosion(ServerWorld world, LivingEntity source, float power) {
        world.createExplosion(source, source.getX(), source.getY() + 0.3, source.getZ(), power, World.ExplosionSourceType.MOB);
    }

    public static void crossfire(ServerWorld world, LivingEntity source, Vec3d direction, float damage) {
        Vec3d forward = direction.normalize();
        Vec3d side = new Vec3d(-forward.z, 0, forward.x).normalize();
        if (side.length() < 0.01) side = new Vec3d(1, 0, 0);
        CombatProjectileEntity.launch(world, source, new ItemStack(SpartanBoss.BLADES), CombatProjectileEntity.SLASH_LEFT,
            forward.subtract(side.multiply(0.16)), damage, side.multiply(1.5));
        CombatProjectileEntity.launch(world, source, new ItemStack(SpartanBoss.BLADES), CombatProjectileEntity.SLASH_RIGHT,
            forward.add(side.multiply(0.16)), damage, side.multiply(-1.5));
        source.playSound(SpartanBoss.DIVINE_SOUND, 1.6f, 1.2f);
    }

    public static void frostSpikes(ServerWorld world, LivingEntity source, double radius) {
        if (!world.getGameRules().getValue(GameRules.DO_MOB_GRIEFING)) return;
        for (int i = 0; i < 18; i++) {
            double angle = Math.PI * 2 * i / 18;
            double distance = 2 + (i % 3) * (radius - 2) / 3.0;
            BlockPos pos = BlockPos.ofFloored(source.getX() + Math.cos(angle) * distance, source.getY(), source.getZ() + Math.sin(angle) * distance);
            if (world.getBlockState(pos).isAir() && !world.getBlockState(pos.down()).isAir()) {
                world.setBlockState(pos, SpartanBoss.TEMPORARY_ICE.getDefaultState());
                if (i % 3 == 0 && world.getBlockState(pos.up()).isAir()) world.setBlockState(pos.up(), SpartanBoss.TEMPORARY_ICE.getDefaultState());
            }
        }
    }

    public static void firePatches(ServerWorld world, LivingEntity source, double radius) {
        if (!world.getGameRules().getValue(GameRules.DO_MOB_GRIEFING)) return;
        for (int i = 0; i < 24; i++) {
            double angle = Math.PI * 2 * i / 24;
            double distance = 2 + (i % 4) * (radius - 2) / 4.0;
            BlockPos pos = BlockPos.ofFloored(source.getX() + Math.cos(angle) * distance, source.getY(), source.getZ() + Math.sin(angle) * distance);
            if (world.getBlockState(pos).isAir() && !world.getBlockState(pos.down()).isAir()) world.setBlockState(pos, SpartanBoss.TEMPORARY_FIRE.getDefaultState());
        }
    }
}