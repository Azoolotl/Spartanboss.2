package com.kodari.spartanboss;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

public class SacredBladesItem extends Item implements GeoItem {
    public static BiConsumer<SacredBladesItem, Consumer<GeoRenderProvider>> rendererFactory = (item, consumer) -> consumer.accept(GeoRenderProvider.DEFAULT);
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public SacredBladesItem(Settings settings) { super(settings); }

    @Override public void createGeoRenderer(Consumer<GeoRenderProvider> consumer) { rendererFactory.accept(this, consumer); }
    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>("static", 0, state -> PlayState.STOP));
    }
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        int mode = Math.floorMod(stack.getOrDefault(DataComponentTypes.CUSTOM_DATA, NbtComponent.DEFAULT).copyNbt().getInt("AbilityMode", 0), 2);
        boolean chaos = this == SpartanBoss.CHAOS_BLADES;
        boolean frost = this == SpartanBoss.FROST_AXE;
        if (user.isSneaking()) {
            if (world instanceof ServerWorld) {
                String[] names = frost ? new String[]{"Frost Stun", "Ice Spikes"}
                    : chaos ? new String[]{"Flame Combo", "Spartan Rage"}
                    : new String[]{"Divine Dash", "Heavenly Crash"};
                int next = (mode + 1) % names.length;
                NbtComponent.set(DataComponentTypes.CUSTOM_DATA, stack, nbt -> nbt.putInt("AbilityMode", next));
                user.sendMessage(Text.literal(names[next]), true);
            }
            return ActionResult.SUCCESS;
        }
        if (user.getItemCooldownManager().isCoolingDown(stack)) return ActionResult.PASS;
        if (world instanceof ServerWorld server) {
            if (chaos) {
                if (mode == 0) {
                    WeaponAbilitySequences.startChaosCombo(server, user, hand, stack);
                } else {
                    user.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 120, 0, false, false));
                    user.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 120, 0, false, false));
                    user.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 120, 0, false, false));
                    WeaponAbilitySequences.startRage(user);
                    server.spawnParticles(new DustParticleEffect(0xE51C10, 1.8f), user.getX(), user.getY() + 1, user.getZ(), 80, 0.8, 0.8, 0.8, 0.08);
                    user.playSound(SpartanBoss.RAGE_SOUND, 1.5f, 1.1f);
                }
                user.getItemCooldownManager().set(stack, mode == 0 ? 160 : 400);
                stack.damage(1, user, hand == Hand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
                user.swingHand(hand, true);
                return ActionResult.SUCCESS;
            }
            if (frost) {
                if (mode == 0) WeaponAbilitySequences.stunNearby(server, user);
                else WeaponAbilitySequences.createFrostSpikes(server, user);
                user.getItemCooldownManager().set(stack, mode == 0 ? 400 : 240);
                stack.damage(1, user, hand == Hand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
                user.swingHand(hand, true);
                return ActionResult.SUCCESS;
            }
            if (mode == 0) WeaponAbilitySequences.startDivineDash(server, user);
            else WeaponAbilitySequences.startHeavenlyCrash(server, user);
            user.getItemCooldownManager().set(stack, mode == 0 ? 160 : 320);
            stack.damage(1, user, hand == Hand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
            user.swingHand(hand, true);
        }
        return ActionResult.SUCCESS;
    }
}