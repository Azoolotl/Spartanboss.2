# SpartanBoss 1.0.4-dev — Voice Integration

## Implemented
- Converted all 14 supplied MP3 voice lines to OGG Vorbis.
- Registered seven voice events for each boss: summoned, ultimate, defeat, damage, and three ambient variations.
- Kratos and Gabriel play their summon line once when first ticked after spawning.
- Their respective ultimate voice line plays when the Phase III ultimate begins.
- Defeat lines play on death.
- Damage lines have a 35% chance after accepted damage and a 55-tick cooldown.
- Ambient lines are randomly selected and spaced 600–1200 ticks apart; they only play while the boss has no target.
- Voice cooldowns and summon-played flags are saved to entity data.
- Existing ability sound events remain in place.

## Validation
- All 14 OGG files were generated and confirmed readable with ffprobe.
- `sounds.json` and all resource JSON files parse successfully.
- ZIP integrity verified.
- Full Fabric build and in-game playback tests were not possible because Gradle is not installed and this source project has no Gradle wrapper.
